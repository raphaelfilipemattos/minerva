package br.com.minerva.minerva.repos;

import br.com.minerva.minerva.domain.PerfilUsuarioEmpresa;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PerfilUsuarioEmpresaRepository extends JpaRepository<PerfilUsuarioEmpresa, UUID> {
}
