package br.com.minerva.minerva.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UsuarioDTO {

    private UUID idusuario;

    @NotNull
    @Size(max = 150)
    private String nome;

    @NotNull
    @Size(max = 200)
    private String email;

    @NotNull
    @Size(max = 11)
    private String cpf;

    @NotNull
    @Size(max = 200)
    private String senha;

    @NotNull
    private Long seq;

    @NotNull
    private OffsetDateTime dataCadastro;

    @NotNull
    private OffsetDateTime lastChange;

}
