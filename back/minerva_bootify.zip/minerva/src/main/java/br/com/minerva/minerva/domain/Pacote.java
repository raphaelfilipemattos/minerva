package br.com.minerva.minerva.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Getter
@Setter
public class Pacote {

    @Id
    @Column(nullable = false, updatable = false)
    @GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
    @GeneratedValue(generator = "uuid")
    private UUID idpacote;

    @Column(nullable = false, length = 50)
    private String descricao;

    @Column(nullable = false, precision = 7, scale = 2)
    private BigDecimal valor;

    @Column(nullable = false)
    private Boolean tipo;

    @Column(nullable = false)
    private Integer maxCursos;

    @Column
    private Integer usoDisco;

    @OneToMany(mappedBy = "idpacote")
    private Set<Empresa> idpacoteEmpresas;

}
