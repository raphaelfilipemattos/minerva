package br.com.minerva.minerva.service;

import br.com.minerva.minerva.domain.Usuario;
import br.com.minerva.minerva.model.UsuarioDTO;
import br.com.minerva.minerva.repos.UsuarioRepository;
import br.com.minerva.minerva.util.NotFoundException;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(final UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<UsuarioDTO> findAll() {
        final List<Usuario> usuarios = usuarioRepository.findAll(Sort.by("idusuario"));
        return usuarios.stream()
                .map(usuario -> mapToDTO(usuario, new UsuarioDTO()))
                .toList();
    }

    public UsuarioDTO get(final UUID idusuario) {
        return usuarioRepository.findById(idusuario)
                .map(usuario -> mapToDTO(usuario, new UsuarioDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public UUID create(final UsuarioDTO usuarioDTO) {
        final Usuario usuario = new Usuario();
        mapToEntity(usuarioDTO, usuario);
        return usuarioRepository.save(usuario).getIdusuario();
    }

    public void update(final UUID idusuario, final UsuarioDTO usuarioDTO) {
        final Usuario usuario = usuarioRepository.findById(idusuario)
                .orElseThrow(NotFoundException::new);
        mapToEntity(usuarioDTO, usuario);
        usuarioRepository.save(usuario);
    }

    public void delete(final UUID idusuario) {
        usuarioRepository.deleteById(idusuario);
    }

    private UsuarioDTO mapToDTO(final Usuario usuario, final UsuarioDTO usuarioDTO) {
        usuarioDTO.setIdusuario(usuario.getIdusuario());
        usuarioDTO.setNome(usuario.getNome());
        usuarioDTO.setEmail(usuario.getEmail());
        usuarioDTO.setCpf(usuario.getCpf());
        usuarioDTO.setSenha(usuario.getSenha());
        usuarioDTO.setSeq(usuario.getSeq());
        usuarioDTO.setDataCadastro(usuario.getDataCadastro());
        usuarioDTO.setLastChange(usuario.getLastChange());
        return usuarioDTO;
    }

    private Usuario mapToEntity(final UsuarioDTO usuarioDTO, final Usuario usuario) {
        usuario.setNome(usuarioDTO.getNome());
        usuario.setEmail(usuarioDTO.getEmail());
        usuario.setCpf(usuarioDTO.getCpf());
        usuario.setSenha(usuarioDTO.getSenha());
        usuario.setSeq(usuarioDTO.getSeq());
        usuario.setDataCadastro(usuarioDTO.getDataCadastro());
        usuario.setLastChange(usuarioDTO.getLastChange());
        return usuario;
    }

    public boolean emailExists(final String email) {
        return usuarioRepository.existsByEmailIgnoreCase(email);
    }

    public boolean cpfExists(final String cpf) {
        return usuarioRepository.existsByCpfIgnoreCase(cpf);
    }

}
