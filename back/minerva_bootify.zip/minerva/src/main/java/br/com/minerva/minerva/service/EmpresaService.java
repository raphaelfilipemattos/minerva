package br.com.minerva.minerva.service;

import br.com.minerva.minerva.domain.Empresa;
import br.com.minerva.minerva.domain.Pacote;
import br.com.minerva.minerva.model.EmpresaDTO;
import br.com.minerva.minerva.repos.EmpresaRepository;
import br.com.minerva.minerva.repos.PacoteRepository;
import br.com.minerva.minerva.util.NotFoundException;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class EmpresaService {

    private final EmpresaRepository empresaRepository;
    private final PacoteRepository pacoteRepository;

    public EmpresaService(final EmpresaRepository empresaRepository,
            final PacoteRepository pacoteRepository) {
        this.empresaRepository = empresaRepository;
        this.pacoteRepository = pacoteRepository;
    }

    public List<EmpresaDTO> findAll() {
        final List<Empresa> empresas = empresaRepository.findAll(Sort.by("idempresa"));
        return empresas.stream()
                .map(empresa -> mapToDTO(empresa, new EmpresaDTO()))
                .toList();
    }

    public EmpresaDTO get(final UUID idempresa) {
        return empresaRepository.findById(idempresa)
                .map(empresa -> mapToDTO(empresa, new EmpresaDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public UUID create(final EmpresaDTO empresaDTO) {
        final Empresa empresa = new Empresa();
        mapToEntity(empresaDTO, empresa);
        return empresaRepository.save(empresa).getIdempresa();
    }

    public void update(final UUID idempresa, final EmpresaDTO empresaDTO) {
        final Empresa empresa = empresaRepository.findById(idempresa)
                .orElseThrow(NotFoundException::new);
        mapToEntity(empresaDTO, empresa);
        empresaRepository.save(empresa);
    }

    public void delete(final UUID idempresa) {
        empresaRepository.deleteById(idempresa);
    }

    private EmpresaDTO mapToDTO(final Empresa empresa, final EmpresaDTO empresaDTO) {
        empresaDTO.setIdempresa(empresa.getIdempresa());
        empresaDTO.setRazaoSocial(empresa.getRazaoSocial());
        empresaDTO.setNomeFantasia(empresa.getNomeFantasia());
        empresaDTO.setCnpjCpf(empresa.getCnpjCpf());
        empresaDTO.setEmailFinanceiro(empresa.getEmailFinanceiro());
        empresaDTO.setEmailEducacional(empresa.getEmailEducacional());
        empresaDTO.setLogo(empresa.getLogo());
        empresaDTO.setSeq(empresa.getSeq());
        empresaDTO.setNomeAmbiente(empresa.getNomeAmbiente());
        empresaDTO.setIdpacote(empresa.getIdpacote() == null ? null : empresa.getIdpacote().getIdpacote());
        return empresaDTO;
    }

    private Empresa mapToEntity(final EmpresaDTO empresaDTO, final Empresa empresa) {
        empresa.setRazaoSocial(empresaDTO.getRazaoSocial());
        empresa.setNomeFantasia(empresaDTO.getNomeFantasia());
        empresa.setCnpjCpf(empresaDTO.getCnpjCpf());
        empresa.setEmailFinanceiro(empresaDTO.getEmailFinanceiro());
        empresa.setEmailEducacional(empresaDTO.getEmailEducacional());
        empresa.setLogo(empresaDTO.getLogo());
        empresa.setSeq(empresaDTO.getSeq());
        empresa.setNomeAmbiente(empresaDTO.getNomeAmbiente());
        final Pacote idpacote = empresaDTO.getIdpacote() == null ? null : pacoteRepository.findById(empresaDTO.getIdpacote())
                .orElseThrow(() -> new NotFoundException("idpacote not found"));
        empresa.setIdpacote(idpacote);
        return empresa;
    }

    public boolean cnpjCpfExists(final String cnpjCpf) {
        return empresaRepository.existsByCnpjCpfIgnoreCase(cnpjCpf);
    }

}
