package br.com.minerva.minerva.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class EmpresaDTO {

    private UUID idempresa;

    @NotNull
    @Size(max = 100)
    private String razaoSocial;

    @NotNull
    @Size(max = 100)
    private String nomeFantasia;

    @NotNull
    @Size(max = 14)
    private String cnpjCpf;

    @NotNull
    @Size(max = 200)
    private String emailFinanceiro;

    @NotNull
    @Size(max = 200)
    private String emailEducacional;

    private UUID logo;

    @NotNull
    private Long seq;

    @NotNull
    @Size(max = 20)
    private String nomeAmbiente;

    @NotNull
    private UUID idpacote;

}
