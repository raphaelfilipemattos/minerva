package br.com.minerva.minerva.service;

import br.com.minerva.minerva.domain.Curso;
import br.com.minerva.minerva.domain.Empresa;
import br.com.minerva.minerva.model.CursoDTO;
import br.com.minerva.minerva.repos.CursoRepository;
import br.com.minerva.minerva.repos.EmpresaRepository;
import br.com.minerva.minerva.util.NotFoundException;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class CursoService {

    private final CursoRepository cursoRepository;
    private final EmpresaRepository empresaRepository;

    public CursoService(final CursoRepository cursoRepository,
            final EmpresaRepository empresaRepository) {
        this.cursoRepository = cursoRepository;
        this.empresaRepository = empresaRepository;
    }

    public List<CursoDTO> findAll() {
        final List<Curso> cursoes = cursoRepository.findAll(Sort.by("idcurso"));
        return cursoes.stream()
                .map(curso -> mapToDTO(curso, new CursoDTO()))
                .toList();
    }

    public CursoDTO get(final UUID idcurso) {
        return cursoRepository.findById(idcurso)
                .map(curso -> mapToDTO(curso, new CursoDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public UUID create(final CursoDTO cursoDTO) {
        final Curso curso = new Curso();
        mapToEntity(cursoDTO, curso);
        return cursoRepository.save(curso).getIdcurso();
    }

    public void update(final UUID idcurso, final CursoDTO cursoDTO) {
        final Curso curso = cursoRepository.findById(idcurso)
                .orElseThrow(NotFoundException::new);
        mapToEntity(cursoDTO, curso);
        cursoRepository.save(curso);
    }

    public void delete(final UUID idcurso) {
        cursoRepository.deleteById(idcurso);
    }

    private CursoDTO mapToDTO(final Curso curso, final CursoDTO cursoDTO) {
        cursoDTO.setIdcurso(curso.getIdcurso());
        cursoDTO.setNomeCurso(curso.getNomeCurso());
        cursoDTO.setApelido(curso.getApelido());
        cursoDTO.setAtivo(curso.getAtivo());
        cursoDTO.setSeq(curso.getSeq());
        cursoDTO.setIdcourseMoodle(curso.getIdcourseMoodle());
        cursoDTO.setValor(curso.getValor());
        cursoDTO.setImagemCapa(curso.getImagemCapa());
        cursoDTO.setDescricaoCompleta(curso.getDescricaoCompleta());
        cursoDTO.setIdempresa(curso.getIdempresa() == null ? null : curso.getIdempresa().getIdempresa());
        return cursoDTO;
    }

    private Curso mapToEntity(final CursoDTO cursoDTO, final Curso curso) {
        curso.setNomeCurso(cursoDTO.getNomeCurso());
        curso.setApelido(cursoDTO.getApelido());
        curso.setAtivo(cursoDTO.getAtivo());
        curso.setSeq(cursoDTO.getSeq());
        curso.setIdcourseMoodle(cursoDTO.getIdcourseMoodle());
        curso.setValor(cursoDTO.getValor());
        curso.setImagemCapa(cursoDTO.getImagemCapa());
        curso.setDescricaoCompleta(cursoDTO.getDescricaoCompleta());
        final Empresa idempresa = cursoDTO.getIdempresa() == null ? null : empresaRepository.findById(cursoDTO.getIdempresa())
                .orElseThrow(() -> new NotFoundException("idempresa not found"));
        curso.setIdempresa(idempresa);
        return curso;
    }

}
