package br.com.minerva.minerva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinervaApplicationTests {

	@Test
	void contextLoads() {
	}

}
